import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Fab
} from '@mui/material';
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  Add as AddIcon
} from '@mui/icons-material';
import { adminGetPaises, adminCreatePais, adminUpdatePais, adminDeletePais } from '../api';

function AdminPaises() {
  const [paises, setPaises] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedPais, setSelectedPais] = useState(null);
  const [formData, setFormData] = useState({
    nombre: '',
    imagen: ''
  });

  const loadPaises = async () => {
    try {
      setLoading(true);
      const response = await adminGetPaises();
      setPaises(response.data || []);
      setError(null);
    } catch (err) {
      setError('Error al cargar países: ' + (err.response?.data?.mensaje || err.message));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPaises();
  }, []);

  const handleAdd = () => {
    setSelectedPais(null);
    setFormData({ nombre: '', imagen: '' });
    setOpenDialog(true);
  };

  const handleEdit = (pais) => {
    setSelectedPais(pais);
    setFormData({
      nombre: pais.nombre || '',
      imagen: pais.imagen || ''
    });
    setOpenDialog(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar este país?')) return;
    
    try {
      await adminDeletePais(id);
      setSuccess('País eliminado correctamente');
      loadPaises();
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError('Error al eliminar país: ' + (err.response?.data?.mensaje || err.message));
      setTimeout(() => setError(null), 5000);
    }
  };

  const handleSave = async () => {
    try {
      if (selectedPais) {
        await adminUpdatePais(selectedPais.idPais, formData);
        setSuccess('País actualizado correctamente');
      } else {
        await adminCreatePais(formData);
        setSuccess('País creado correctamente');
      }
      setOpenDialog(false);
      loadPaises();
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError('Error al guardar país: ' + (err.response?.data?.mensaje || err.message));
      setTimeout(() => setError(null), 5000);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
          Gestión de Países
        </Typography>
        <Fab color="primary" size="medium" onClick={handleAdd} title="Agregar País">
          <AddIcon />
        </Fab>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess(null)}>{success}</Alert>}

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow sx={{ backgroundColor: 'primary.main' }}>
              <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>ID</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Nombre</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Imagen</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {paises.map((pais) => (
              <TableRow key={pais.idPais} hover>
                <TableCell>{pais.idPais}</TableCell>
                <TableCell>{pais.nombre}</TableCell>
                <TableCell>
                  {pais.imagen && (
                    <img 
                      src={pais.imagen} 
                      alt={pais.nombre}
                      style={{ width: '50px', height: '30px', objectFit: 'cover', borderRadius: '4px' }}
                    />
                  )}
                </TableCell>
                <TableCell>
                  <IconButton 
                    size="small" 
                    color="primary" 
                    onClick={() => handleEdit(pais)}
                    title="Editar"
                  >
                    <EditIcon />
                  </IconButton>
                  <IconButton 
                    size="small" 
                    color="error" 
                    onClick={() => handleDelete(pais.idPais)}
                    title="Eliminar"
                  >
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Dialog para crear/editar */}
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{selectedPais ? 'Editar País' : 'Nuevo País'}</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
            <TextField
              label="Nombre"
              name="nombre"
              value={formData.nombre}
              onChange={handleChange}
              fullWidth
              required
            />
            <TextField
              label="URL de Imagen"
              name="imagen"
              value={formData.imagen}
              onChange={handleChange}
              fullWidth
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Cancelar</Button>
          <Button onClick={handleSave} variant="contained" color="primary">
            {selectedPais ? 'Actualizar' : 'Crear'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

export default AdminPaises;
